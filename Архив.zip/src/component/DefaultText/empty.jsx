import React from "react";

export const EmptyMessage = () => <div>Empty</div>;
