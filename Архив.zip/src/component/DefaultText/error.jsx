import React from "react";

export const ErrorMessage = () => <div>Something went wrong :(</div>;
