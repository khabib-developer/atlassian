# Atlassian Connect App using Express

Congratulations!
You've successfully created an Atlassian Connect App using the Express web application framework.

## What's next?

[Read the docs](https://bitbucket.org/atlassian/atlassian-connect-express/src/master/README.md).

## Releasing new changes

See all branches: https://bitbucket.org/atlassian/atlassian-connect-express-template/branches/

`master` branch is for products jira, jira-service-desk, and confluence; `bitbucket` branch is for product bitbucket. When updating `master`, please also update `bitbucket` if neccessary.

The branches will be downloaded by: https://bitbucket.org/atlassian/atlas-connect